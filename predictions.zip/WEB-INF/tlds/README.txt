﻿Configures references to custom tags.
