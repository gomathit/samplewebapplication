/** Utility classes used across more than one feature. */
package hirondelle.predict.util;
