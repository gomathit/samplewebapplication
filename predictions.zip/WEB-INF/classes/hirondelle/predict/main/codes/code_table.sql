

FETCH_OUTCOME_CODES {
 SELECT Id, Text, Weight
 FROM Outcome
 ORDER BY DisplayOrder
}

