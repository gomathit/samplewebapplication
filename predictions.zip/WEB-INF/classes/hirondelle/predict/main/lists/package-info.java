/** 
 Named lists of predictions.
 <P>Users can arrange their predictions into different lists, as a 
 simple tool for organizing. 
*/
package hirondelle.predict.main.lists;
