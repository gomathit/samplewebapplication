/**
 Allow user to change their preferences.
 
 <P>In addition, the Model Object of this feature is defined in order to be useful to 
 the login feature. 
 */
package hirondelle.predict.main.preferences;
