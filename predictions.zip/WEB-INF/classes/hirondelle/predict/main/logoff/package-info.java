/** Log off the application, and terminate the session. */
package hirondelle.predict.main.logoff;
