/** List and edit individual predictions. */
package hirondelle.predict.main.prediction;
