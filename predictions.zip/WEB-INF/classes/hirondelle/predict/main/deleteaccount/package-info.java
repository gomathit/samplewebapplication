/** Delete all information related to an account. */
package hirondelle.predict.main.deleteaccount;
