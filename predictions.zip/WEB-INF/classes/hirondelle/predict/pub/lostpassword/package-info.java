/** 
 Let the user change their password, without knowing their current password.
 This is a two-step process; this package is the first step.
 
 <P>The second step is to reset the password. 
 See the hirondelle.predict.pub.resetpassword package for more information.
*/ 
package hirondelle.predict.pub.lostpassword;
