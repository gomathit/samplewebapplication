/**
 Reacts to successful user login by invoking Login.  
 
 CsrfDAO exists only to declare SqlIds. 
 */
package hirondelle.predict.pub.login;
