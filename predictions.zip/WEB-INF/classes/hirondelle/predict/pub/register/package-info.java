/** Register a new user. */ 
package hirondelle.predict.pub.register;
