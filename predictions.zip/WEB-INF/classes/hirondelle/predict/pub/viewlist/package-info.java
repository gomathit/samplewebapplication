/**
 View a single list of predictions. 
 This Action is wide open to the public, with no restriction.
 The Search screen has search results which include links to this Action.  
*/
package hirondelle.predict.pub.viewlist;
