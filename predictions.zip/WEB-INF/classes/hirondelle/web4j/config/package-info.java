/**
Concrete implementation classes for interfaces defined by WEB4J.

<p>Please see the 
<a href='http://www.web4j.com/UserGuide.jsp#ConfiguringClasses'>User Guide</a> 
for important information about this special package.
*/
package hirondelle.web4j.config;
