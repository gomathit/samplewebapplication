﻿There is some cruft in this directory. Needs some cleanup.
Not all items are actually referenced in the application.